function multiply(a, b){
	let result;
	result = a * b;
	return result;
}
