function print() {
	let input1Value = document.getElementById('input1').value;
	document.getElementById('p1').innerHTML = input1Value;
}