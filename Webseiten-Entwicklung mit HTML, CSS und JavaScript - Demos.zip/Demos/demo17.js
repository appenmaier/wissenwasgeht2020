function setText(){
	document.getElementById("input1").value = 'Hallo Welt';
	document.getElementById('p1').innerHTML = 'Hallo Welt';
}
