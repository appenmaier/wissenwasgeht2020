function add(a, b) {
	let result;
	result = a + b;
	return result;
}

function subtract(a, b) {
	let result;
	result = a - b;
	return result;
}

function multiply(a, b) {
	let result;
	result = a * b;
	return result;
}

function divide(a, b) {
	let result;
	result = a / b;
	return result;
}