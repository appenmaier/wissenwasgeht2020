function add() {
	let a = Number(document.getElementById('input1').value);
	let b = Number(document.getElementById('input2').value);
	let result;
	result = a + b;
	document.getElementById('p1').innerHTML = 'Ergebnis: ' + result;
}

function subtract() {
	let a = document.getElementById('input1').value;
	let b = document.getElementById('input2').value;
	let result;
	result = a - b;
	document.getElementById('p1').innerHTML = 'Ergebnis: ' + result;
}

function multiply() {
	let a = document.getElementById('input1').value;
	let b = document.getElementById('input2').value;
	let result;
	result = a * b;
	document.getElementById('p1').innerHTML = 'Ergebnis: ' + result;
}

function divide() {
	let a = document.getElementById('input1').value;
	let b = document.getElementById('input2').value;
	let result;
	result = a / b;
	document.getElementById('p1').innerHTML = 'Ergebnis: ' + result;
}